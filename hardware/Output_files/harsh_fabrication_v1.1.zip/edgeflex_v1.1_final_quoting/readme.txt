Folders content:

	bom -> components, designators and comments(do not place or provided by us)

	pick_and_place -> pick and place.txt

	reference_pdf_img -> pdf3D overview, boards/layer prints pdf, reference images(just for visual reference)

	gerbers_and_drills -> gerber files and nc drills


Buildup/Stackup: (This stackup could be a bit different depending on your manufacturing constraints)
	Top copper:      0.018mm
	Prepreg:         0.075mm
	Inner copper 1:  0.018mm
	Core:            0.51mm
	Inner copper 2:  0.018mm
	Prepreg:         0.115mm
	Prepreg:         0.115mm
	Inner copper 3:  0.018mm
	Core:            0.51mm
	Inner copper 4:  0.018mm
	Prepreg:         0.075mm
	Bottom copper:   0.018mm

	Objectives summary: Inner 1 and 4 should have ~50ohms for 4.5mils tracks and bottom layer 120 ohms for 10mils tracks.

Assembly notes:
	PCB1 - Completely mounted
	PCB2 - Completely mounted
	PCB3 - Mounted without memories model B and D, only the model F (only the U4 slot)
	PCB4 - Mounted without memories model B and D, only the model F (in the three slots, U2/U3/U4)


